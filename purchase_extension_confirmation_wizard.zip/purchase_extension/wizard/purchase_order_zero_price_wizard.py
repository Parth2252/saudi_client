from odoo import models, fields, api, _, Command

class PurchaseOrderZeroPriceWizard(models.TransientModel):
    _name = "purchase.order.zero.price.wizard"
    _description = "Handle zero price and missing fields during PO confirmation"

    order_id = fields.Many2one("purchase.order", string="Purchase Order")
    
    # Header fields to fix
    purchase_source = fields.Selection([
        ("standard", "Standard Purchase"),
        ("local", "Local Purchase"),
        ("online", "Online Purchase"),
    ], string="Purchase Source")
    po_reference = fields.Char(string="PO Reference")
    sale_partner_id = fields.Many2one("res.partner", string="Sale Customer")
    user_id = fields.Many2one("res.users", string="Buyer")
    attachment_type_ids = fields.Many2many("purchase.attachment.type", string="Attachment Type")
    date_planned = fields.Datetime(string="Expected Arrival Date")

    # Visibility flags for header fields
    show_purchase_source = fields.Boolean()
    show_po_reference = fields.Boolean()
    show_sale_partner_id = fields.Boolean()
    show_user_id = fields.Boolean()
    show_attachment_type_ids = fields.Boolean()
    show_date_planned = fields.Boolean()

    line_ids = fields.One2many("purchase.order.zero.price.wizard.line", "wizard_id", string="Order Lines")

    def action_confirm_po(self):
        self.ensure_one()
        po_vals = {}
        if self.show_purchase_source: po_vals['purchase_source'] = self.purchase_source
        if self.show_po_reference: po_vals['po_reference'] = self.po_reference
        if self.show_sale_partner_id: po_vals['sale_partner_id'] = self.sale_partner_id.id
        if self.show_user_id: po_vals['user_id'] = self.user_id.id
        if self.show_attachment_type_ids: po_vals['attachment_type_ids'] = [Command.set(self.attachment_type_ids.ids)]
        if self.show_date_planned: po_vals['date_planned'] = self.date_planned
        
        if po_vals:
            self.order_id.write(po_vals)

        for line in self.line_ids:
            line_vals = {}
            if line.show_price_unit:
                line_vals['price_unit'] = line.price_unit
            if line.show_customer_pdd:
                line_vals['customer_pdd'] = line.customer_pdd
            
            if line_vals:
                line.po_line_id.write(line_vals)
        
        return self.order_id.button_confirm()


class PurchaseOrderZeroPriceWizardLine(models.TransientModel):
    _name = "purchase.order.zero.price.wizard.line"
    _description = "Check Line Item"

    wizard_id = fields.Many2one("purchase.order.zero.price.wizard")
    po_line_id = fields.Many2one("purchase.order.line", string="Original PO Line")
    sr_no_po = fields.Integer(related="po_line_id.sr_no_po", string="Order No")
    product_id = fields.Many2one("product.product", related="po_line_id.product_id", string="Product")
    name = fields.Text(related="po_line_id.name", string="Product Name")
    product_qty = fields.Float(related="po_line_id.product_qty", string="Quantity")
    
    # Fields to fix
    price_unit = fields.Float(string="Unit Price")
    customer_pdd = fields.Datetime(string="Customer PDD")
    
    # Visibility flags
    show_price_unit = fields.Boolean()
    show_customer_pdd = fields.Boolean()
    
    price_subtotal = fields.Float(compute="_compute_price_subtotal", string="Total")

    @api.depends('product_qty', 'price_unit')
    def _compute_price_subtotal(self):
        for line in self:
            line.price_subtotal = line.product_qty * line.price_unit
